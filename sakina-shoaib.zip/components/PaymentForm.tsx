
"use client";

import { useState } from "react";


export default function PurchaseForm(){

const [submitted,setSubmitted] = useState(false);



async function handleSubmit(
e:React.FormEvent<HTMLFormElement>
){

e.preventDefault();


const form = e.currentTarget;


const data = new FormData(form);



await fetch(
"https://formspree.io/f/mnjezyzg",
{

method:"POST",

body:data,

headers:{

Accept:"application/json"

}

}
);


setSubmitted(true);


}






if(submitted){

return (

<div

className="
bg-[#FCF8F5]
rounded-3xl
p-12
text-center
"

>


<div

className="
text-[#C48B9F]
text-4xl
"

>

✦

</div>


<h2

className="
text-4xl
mt-6
"

>

Thank You

</h2>



<p

className="
mt-6
text-gray-600
leading-relaxed
"

>

Your order has been received.

After payment verification,
your book will be delivered.

</p>


</div>


)

}







return (

<form

onSubmit={handleSubmit}

className="
space-y-6
bg-white
border
border-[#E8D9D0]
rounded-3xl
p-8
shadow-sm
"

>




<h2

className="
text-3xl
text-center
"

>

Complete Your Order

</h2>





<input

name="name"

required

placeholder="Your Name"

className="
w-full
border-b
border-[#E8D9D0]
py-4
outline-none
focus:border-[#6B3A5B]
"

/>






<input

name="email"

type="email"

required

placeholder="Email Address"

className="
w-full
border-b
border-[#E8D9D0]
py-4
outline-none
focus:border-[#6B3A5B]
"

/>







<div>


<p className="
mb-4
text-gray-600
">

Choose Edition

</p>



<label className="
flex
gap-3
items-center
"

>

<input

type="radio"

name="edition"

value="Digital Edition"

defaultChecked

/>

Digital Edition

</label>





<label className="
flex
gap-3
items-center
mt-3
"

>

<input

type="radio"

name="edition"

value="Paperback Edition"

/>

Paperback Edition

</label>


</div>







<input

name="paymentReference"

required

placeholder="Payment Reference / Transaction ID"

className="
w-full
border-b
border-[#E8D9D0]
py-4
outline-none
focus:border-[#6B3A5B]
"

/>








<textarea

name="message"

placeholder="Additional notes"

rows={4}

className="
w-full
border
border-[#E8D9D0]
rounded-xl
p-4
outline-none
focus:border-[#6B3A5B]
"

/>







<button

className="
w-full
bg-[#6B3A5B]
text-white
py-4
rounded-full
hover:-translate-y-1
transition
shadow-lg
"

>

Confirm Order

</button>






</form>


)

}