"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { siteData } from "@/data/site";


export default function Hero(){

return (

<section

className="
relative
min-h-screen
flex
items-center
justify-center
px-6
pt-24
pb-32
overflow-hidden
"

>


{/* Soft paper glow */}

<div

className="
absolute
top-20
left-1/2
-translate-x-1/2
w-[600px]
h-[600px]
rounded-full
bg-[#F7EFEA]
blur-3xl
opacity-70
"

></div>





<div

className="
relative
max-w-5xl
mx-auto
text-center
"

>




{/* Release label */}


<motion.p

initial={{

opacity:0,
y:-20

}}

animate={{

opacity:1,
y:0

}}

transition={{

duration:.8

}}

className="
uppercase
tracking-[0.45em]
text-xs
text-[#6B3A5B]
"

>

New Release

</motion.p>






{/* Book */}


<motion.div

initial={{

opacity:0,
scale:.8

}}

animate={{

opacity:1,
scale:1

}}

transition={{

duration:1

}}

className="
mt-14
flex
justify-center
"

>


<motion.div

whileHover={{

scale:1.04,
rotate:1

}}

transition={{

type:"spring",
stiffness:150

}}

>


<Image

src={siteData.book.cover}

alt={siteData.book.title}

width={380}

height={570}

priority

className="
rounded-lg
shadow-2xl
"

/>


</motion.div>


</motion.div>







{/* Author */}


<motion.p

initial={{

opacity:0

}}

animate={{

opacity:1

}}

transition={{

delay:.5

}}

className="
mt-14
uppercase
tracking-[0.35em]
text-sm
text-gray-500
"

>

By Sakina Shoaib

</motion.p>







{/* Title */}


<motion.h1

initial={{

opacity:0,
y:30

}}

animate={{

opacity:1,
y:0

}}

transition={{

delay:.6

}}

className="
mt-6
text-6xl
md:text-8xl
text-[#2B2B2B]
leading-tight
"

>

{siteData.book.title}

</motion.h1>







{/* Decorative symbol */}


<div

className="
my-10
text-[#C48B9F]
text-2xl
"

>

✦

</div>






{/* Description */}


<motion.p

initial={{

opacity:0

}}

animate={{

opacity:1

}}

transition={{

delay:.8

}}

className="
max-w-2xl
mx-auto
text-lg
text-gray-600
leading-relaxed
"

>

{siteData.book.tagline}

</motion.p>







{/* Button */}


<Link

href="/buy"

className="
inline-flex
items-center
justify-center
mt-12
px-12
py-4
rounded-full
bg-[#6B3A5B]
text-white
tracking-wide
shadow-lg
hover:-translate-y-1
hover:shadow-xl
transition
"

>

Purchase The Book

</Link>



</div>


</section>


);

}