"use client";

import { motion } from "framer-motion";
import { siteData } from "@/data/site";
import Link from "next/link";


export default function Synopsis(){

return (

<section

className="
py-40
px-6
bg-white
"

>


<div

className="
max-w-5xl
mx-auto
"

>



{/* Heading */}

<motion.div

initial={{

opacity:0

}}

whileInView={{

opacity:1

}}

viewport={{

once:true

}}

className="
text-center
"

>


<p

className="
uppercase
tracking-[0.45em]
text-xs
text-[#6B3A5B]
"

>

About The Story

</p>




<h2

className="
mt-8
text-5xl
md:text-6xl
"

>

A Story Worth Remembering

</h2>





<div

className="
mt-8
text-[#C48B9F]
"

>

✦

</div>


</motion.div>








{/* Book style area */}



<motion.div

initial={{

opacity:0,
y:40

}}

whileInView={{

opacity:1,
y:0

}}

viewport={{

once:true

}}

className="
mt-20
bg-[#FCF8F5]
rounded-3xl
p-10
md:p-16
shadow-sm
border
border-[#E8D9D0]
"

>





<p

className="
text-2xl
italic
text-gray-600
text-center
leading-relaxed
"

>

"{siteData.book.tagline}"

</p>







<div

className="
mt-14
text-lg
leading-loose
text-gray-700
"

>



<p>

<span

className="
float-left
text-7xl
font-serif
leading-none
mr-3
text-[#6B3A5B]
"

>

{siteData.book.synopsis?.charAt(0)}

</span>


{siteData.book.synopsis?.slice(1)}

</p>




</div>









<Link

href="/buy"

className="
inline-block
mt-12
text-[#6B3A5B]
border-b
border-[#6B3A5B]
pb-2
tracking-wide
hover:text-[#C48B9F]
hover:border-[#C48B9F]
transition
"

>

Discover The Book →

</Link>



</motion.div>






</div>


</section>


);

}