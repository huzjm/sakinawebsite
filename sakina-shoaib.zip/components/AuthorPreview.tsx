"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { siteData } from "@/data/site";


export default function AuthorPreview(){

return (

<section

className="
py-40
px-6
bg-[#FCF8F5]
"

>


<div

className="
max-w-6xl
mx-auto
"

>



{/* Header */}

<motion.div

initial={{
opacity:0
}}

whileInView={{
opacity:1
}}

viewport={{
once:true
}}

className="
text-center
"

>


<p

className="
uppercase
tracking-[0.45em]
text-xs
text-[#6B3A5B]
"

>

The Author

</p>



<h2

className="
mt-8
text-5xl
md:text-6xl
"

>

Sakina Shoaib

</h2>



<div

className="
mt-8
text-[#C48B9F]
text-xl
"

>

✦

</div>


</motion.div>









<div

className="
mt-20
grid
md:grid-cols-2
gap-16
items-center
"

>






{/* Portrait */}


<motion.div

initial={{

opacity:0,
x:-40

}}

whileInView={{

opacity:1,
x:0

}}

viewport={{

once:true

}}

>


<div

className="
relative
max-w-md
mx-auto
"

>


<Image

src={siteData.author.image}

alt="Sakina Shoaib"

width={500}

height={650}

className="
rounded-2xl
shadow-xl
"

priority

/>


</div>


</motion.div>









{/* Text */}


<motion.div

initial={{

opacity:0,
x:40

}}

whileInView={{

opacity:1,
x:0

}}

viewport={{

once:true

}}

>


<p

className="
uppercase
tracking-[0.3em]
text-sm
text-gray-500
"

>

Writer • Storyteller

</p>




<h3

className="
mt-6
text-4xl
"

>

About Sakina

</h3>




<p

className="
mt-8
text-lg
leading-relaxed
text-gray-600
"

>

{siteData.author.bio}

</p>





<div

className="
mt-10
text-[#C48B9F]
font-serif
text-3xl
italic
"

>

Sakina Shoaib

</div>



</motion.div>





</div>





</div>


</section>


);

}