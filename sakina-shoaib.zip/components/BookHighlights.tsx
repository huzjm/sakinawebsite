"use client";

import { motion } from "framer-motion";
import { siteData } from "@/data/site";


export default function BookHighlights(){

return (

<section

className="
py-40
px-6
bg-white
"

>


<div

className="
max-w-5xl
mx-auto
text-center
"

>




<motion.p

initial={{
opacity:0
}}

whileInView={{
opacity:1
}}

viewport={{
once:true
}}

className="
uppercase
tracking-[0.45em]
text-xs
text-[#6B3A5B]
"

>

Inside The Book

</motion.p>






<h2

className="
mt-8
text-5xl
md:text-6xl
"

>

Discover The Journey

</h2>





<div

className="
mt-8
text-[#C48B9F]
"

>

✦

</div>









<div

className="
mt-20
grid
md:grid-cols-2
gap-x-20
gap-y-16
text-left
"

>



{

siteData.book.highlights.map((item,index)=>(


<motion.div

key={item.title}

initial={{

opacity:0,
y:30

}}

whileInView={{

opacity:1,
y:0

}}

viewport={{

once:true

}}

transition={{

delay:index*.15

}}

className="
flex
gap-6
"

>


<div

className="
text-[#C48B9F]
text-xl
"

>

✦

</div>



<div>


<h3

className="
text-2xl
"

>

{item.title}

</h3>



<p

className="
mt-3
text-gray-600
leading-relaxed
"

>

{item.description}

</p>


</div>



</motion.div>


))


}


</div>





</div>


</section>


);

}