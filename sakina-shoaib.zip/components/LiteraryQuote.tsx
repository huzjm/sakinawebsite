"use client";

import { motion } from "framer-motion";


export default function LiteraryQuote(){

return (

<section

className="
py-40
px-6
bg-[#FCF8F5]
"

>


<div

className="
max-w-4xl
mx-auto
text-center
"

>



<motion.div

initial={{

opacity:0,
scale:.8

}}

whileInView={{

opacity:1,
scale:1

}}

viewport={{

once:true

}}

className="
text-[#C48B9F]
text-3xl
"

>

✦

</motion.div>






<motion.blockquote

initial={{

opacity:0,
y:30

}}

whileInView={{

opacity:1,
y:0

}}

viewport={{

once:true

}}

transition={{

duration:.8

}}

className="
mt-10
text-4xl
md:text-6xl
leading-tight
font-serif
text-[#2B2B2B]
"

>

"Every story carries a piece of the
heart that created it."

</motion.blockquote>







<motion.div

initial={{

opacity:0

}}

whileInView={{

opacity:1

}}

viewport={{

once:true

}}

transition={{

delay:.4

}}

className="
mt-10
uppercase
tracking-[0.4em]
text-sm
text-gray-500
"

>

Sakina Shoaib

</motion.div>






<div

className="
mt-10
text-[#C48B9F]
"

>

✦

</div>



</div>


</section>


);

}