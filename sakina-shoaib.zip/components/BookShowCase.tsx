"use client";

import { motion } from "framer-motion";
import { siteData } from "@/data/site";


export default function BookShowcase(){

return (

<section

className="
py-32
px-6
bg-white
"

>


<div

className="
max-w-6xl
mx-auto
text-center
"

>



<motion.p

initial={{
opacity:0
}}

whileInView={{
opacity:1
}}

viewport={{
once:true
}}

className="
uppercase
tracking-[0.4em]
text-xs
text-[#6B3A5B]
"

>

The Book

</motion.p>





<h2

className="
mt-8
text-5xl
md:text-6xl
"

>

{siteData.book.title}

</h2>






<div

className="
mt-8
text-[#C48B9F]
text-2xl
"

>

✦

</div>






<p

className="
max-w-2xl
mx-auto
mt-8
text-lg
text-gray-600
leading-relaxed
"

>

{siteData.book.tagline}

</p>








<div

className="
grid
md:grid-cols-2
gap-8
mt-16
"

>





{/* Ebook */}

<motion.div

whileHover={{

y:-8

}}

className="
rounded-3xl
border
border-[#E8D9D0]
p-10
"

>


<h3

className="
text-3xl
"

>

Digital Edition

</h3>



<p

className="
mt-4
text-gray-600
"

>

PDF ebook delivered after confirmation.

</p>




<p

className="
mt-8
text-3xl
text-[#6B3A5B]
"

>

{siteData.book.ebookPrice}

</p>



</motion.div>







{/* Paperback */}



<motion.div

whileHover={{

y:-8

}}

className="
rounded-3xl
border
border-[#E8D9D0]
p-10
"

>


<h3

className="
text-3xl
"

>

Paperback Edition

</h3>



<p

className="
mt-4
text-gray-600
"

>

A physical copy delivered to your doorstep.

</p>




<p

className="
mt-8
text-3xl
text-[#6B3A5B]
"

>

{siteData.book.paperbackPrice}

</p>



</motion.div>



</div>









{/* Details */}



<div

className="
grid
grid-cols-3
gap-6
mt-20
border-t
border-[#E8D9D0]
pt-12
"

>


<div>

<p className="
text-sm
uppercase
tracking-widest
text-gray-500
">

Format

</p>


<p className="
mt-3
text-xl
">

Digital / Print

</p>

</div>




<div>

<p className="
text-sm
uppercase
tracking-widest
text-gray-500
">

Language

</p>


<p className="
mt-3
text-xl
">

English

</p>

</div>





<div>

<p className="
text-sm
uppercase
tracking-widest
text-gray-500
">

Availability

</p>


<p className="
mt-3
text-xl
">

Available Now

</p>

</div>



</div>



</div>


</section>


);

}