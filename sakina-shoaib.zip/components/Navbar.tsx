"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import { useState, useEffect } from "react";


const links = [

{
name:"Home",
href:"/"
},

{
name:"About",
href:"/about"
},

{
name:"Books",
href:"/buy"
},

{
name:"Contact",
href:"/contact"
}

];



export default function Navbar(){

const pathname = usePathname();

const [scrolled,setScrolled] = useState(false);

const [open,setOpen] = useState(false);



useEffect(()=>{


const handleScroll=()=>{

setScrolled(window.scrollY > 60);

};


window.addEventListener(
"scroll",
handleScroll
);


return ()=>{

window.removeEventListener(
"scroll",
handleScroll
);

};


},[]);



return (

<header

className={`
fixed
top-0
left-0
right-0
z-50
transition-all
duration-500

${

scrolled

?

"bg-[#FCF8F5]/90 backdrop-blur-xl shadow-sm"

:

"bg-transparent"

}

`}

>



<div

className={`
max-w-6xl
mx-auto
px-6
transition-all
duration-500

${

scrolled

?

"py-4"

:

"py-8"

}

`}

>



{/* BRAND */}


<div

className="
text-center
"

>


<motion.div

animate={{

scale:scrolled ? .85 : 1

}}

transition={{

duration:.4

}}

>


{/* <div

className="
text-[#C48B9F]
text-xl
"

>

✦

</div> */}



<h1

className="
font-serif
text-4xl
text-[#6B3A5B]
"

>

Sakina Shoaib

</h1>



<p

className="
uppercase
tracking-[0.35em]
text-xs
text-gray-500
mt-2
"

>

Author • Storyteller

</p>


</motion.div>


</div>





{/* DESKTOP NAV */}


<nav

className="
hidden
md:flex
justify-center
gap-12
mt-8
"

>


{

links.map(link=>{


const active =
pathname===link.href;



return (

<Link

key={link.href}

href={link.href}

className="
relative
uppercase
tracking-[0.25em]
text-sm
text-gray-700
"

>


{link.name}



<motion.span

initial={false}

animate={{

scaleX:

active ? 1 : 0

}}

className="
absolute
left-0
right-0
bottom-[-8px]
h-[1px]
bg-[#C48B9F]
origin-center
"

>



</motion.span>



</Link>


)


})


}


</nav>






{/* MOBILE BUTTON */}


<button

onClick={()=>setOpen(!open)}

className="
md:hidden
absolute
right-6
top-8
text-2xl
"

>

{

open

?

"×"

:

"☰"

}


</button>







{/* MOBILE MENU */}


{

open &&

(

<motion.nav

initial={{

opacity:0,
height:0

}}

animate={{

opacity:1,
height:"auto"

}}

className="
md:hidden
mt-8
border-t
border-[#E8D9D0]
pt-8
flex
flex-col
items-center
gap-8
"

>

{

links.map(link=>(

<Link

key={link.href}

href={link.href}

onClick={()=>setOpen(false)}

className="
uppercase
tracking-[0.25em]
text-sm
"

>

{link.name}

</Link>


))

}


</motion.nav>

)

}



</div>


</header>


);

}