export const siteData = {

  author: {
    name: "Sakina Shoaib",

    title: "Author",

    bio: `
    Sakina Shoaib is a passionate writer whose work explores
    emotions, experiences, and stories that connect deeply
    with readers.
    `,

    image: "/images/author.jpg",
  },


  book: {

    title: "Your Book Title",

    tagline:
      "A story of emotions, memories, and unforgettable moments.",


    synopsis: `
    Add the official book synopsis here.
    This section introduces readers to the world,
    themes, and journey behind the book.
    `,


    cover:
      "/images/book-cover.png",


    ebookPrice:
      "PKR 750",


    paperbackPrice:
      "PKR 2000",
      highlights:[
{
title:"Themes",
description:"A reflection on love, memories, and the moments that shape us."
},
{
title:"A Personal Journey",
description:"A story exploring emotions, relationships, and human connection."
},
{
title:"The Experience",
description:"Written to create a lasting emotional connection with every reader."
},
{
title:"For Every Reader",
description:"A heartfelt story that invites reflection and imagination."
}
]

  },


  contact: {

    email:
      "author@email.com",

    whatsapp:
      "+92 XXX XXXXXXX",

  },


  payment: {

    bank:
      "Your Bank Name",
  account: "",

    accountName:
      "Sakina Shoaib",

    accountNumber:
      "XXXXXXXX",

    iban:
      "PK00 XXXX XXXX",

  },
  


};