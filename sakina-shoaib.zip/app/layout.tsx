import type { Metadata } from "next";
import MobileBuyButton from "@/components/MobileBuyButton";
import { Playfair_Display, Lora } from "next/font/google";
import "./globals.css";
import PageTransition from "@/components/PageTransition";


const playfair = Playfair_Display({

  variable: "--font-playfair",

  subsets:["latin"],

});

const lora = Lora({

  variable:"--font-lora",

  subsets:["latin"],

});
export const metadata: Metadata = {

title:
"Sakina Shoaib | Author & Storyteller",


description:
"Official website of Sakina Shoaib. Discover her latest book, read the story behind it, and order your copy.",



keywords:[

"Sakina Shoaib",

"author",

"book",

"Pakistani author",

"novel",

"ebook"

],



authors:[

{

name:"Sakina Shoaib"

}

],



openGraph:{

title:
"Sakina Shoaib | Author & Storyteller",


description:
"Discover the latest book by Sakina Shoaib.",


type:"website",


locale:"en_PK",


images:[

{

url:"/images/book-cover.png",

width:800,

height:1200,

alt:"Sakina Shoaib Book Cover"

}

]

},



twitter:{

card:"summary_large_image",

title:
"Sakina Shoaib | Author & Storyteller",

description:
"Discover the latest book by Sakina Shoaib.",


images:[

"/images/book-cover.png"

]

}



};

export default function RootLayout({

children,

}: Readonly<{

children: React.ReactNode;

}>) {


return (

<html lang="en">

<body

className={`
${playfair.variable}
${lora.variable}
antialiased
`}

>

<PageTransition>

<div className="pt-32">

{children}

</div>

</PageTransition>
<MobileBuyButton />
</body>


</html>

);

}