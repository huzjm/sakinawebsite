import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Hero from "@/components/Hero";
import Synopsis from "@/components/Synopsis";
import AuthorPreview from "@/components/AuthorPreview";
import BookHighlights from "@/components/BookHighlights";
import BookShowcase from "@/components/BookShowCase";
import LiteraryQuote from "@/components/LiteraryQuote";
export default function Home() {

  return (

    <main>

      <Navbar />
    <AuthorPreview />
    <BookShowcase />
    <BookHighlights />
<LiteraryQuote />

      <Hero />
      <Synopsis />
      
      <Footer />

    </main>

  );

}