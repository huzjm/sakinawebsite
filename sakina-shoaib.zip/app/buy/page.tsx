import Image from "next/image";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { siteData } from "@/data/site";
import PaymentForm from "@/components/PaymentForm";


export default function BuyPage(){

return (

<main>

<Navbar />


<section

className="
py-40
px-6
"

>


<div

className="
max-w-6xl
mx-auto
"

>


{/* Heading */}


<div

className="
text-center
"

>


<p

className="
uppercase
tracking-[0.45em]
text-xs
text-[#6B3A5B]
"

>

Purchase

</p>


<h1

className="
mt-8
text-6xl
"

>

Get Your Copy

</h1>


<div

className="
mt-8
text-[#C48B9F]
"

>

✦

</div>


</div>






{/* Product */}


<div

className="
mt-20
grid
md:grid-cols-2
gap-16
items-center
"

>



<div

className="
flex
justify-center
"

>


<Image

src={siteData.book.cover}

alt={siteData.book.title}

width={350}

height={520}

className="
rounded-xl
shadow-2xl
"

/>


</div>







<div>


<h2

className="
text-4xl
"

>

{siteData.book.title}

</h2>



<p

className="
mt-6
text-gray-600
leading-relaxed
"

>

Choose your preferred edition.

Your order will be confirmed manually
and delivered after payment verification.

</p>







<div

className="
mt-10
space-y-6
"

>



<div

className="
border-b
border-[#E8D9D0]
pb-5
"

>


<h3

className="
text-2xl
"

>

Digital Edition

</h3>


<p

className="
mt-2
text-[#6B3A5B]
text-3xl
"

>

{siteData.book.ebookPrice}

</p>


</div>





<div

className="
border-b
border-[#E8D9D0]
pb-5
"

>


<h3

className="
text-2xl
"

>

Paperback Edition

</h3>


<p

className="
mt-2
text-[#6B3A5B]
text-3xl
"

>

{siteData.book.paperbackPrice}

</p>


</div>



</div>



</div>


</div>





</div>


</section>








{/* Process */}



<section

className="
py-32
bg-[#FCF8F5]
px-6
"

>


<div

className="
max-w-5xl
mx-auto
text-center
"

>


<h2

className="
text-5xl
"

>

How It Works

</h2>



<div

className="
grid
md:grid-cols-3
gap-10
mt-16
"

>


<div>

<div className="
text-[#C48B9F]
text-3xl
">

01

</div>


<h3 className="
mt-4
text-2xl
">

Payment

</h3>


<p className="
mt-3
text-gray-600
">

Transfer payment using the provided bank details.

</p>

</div>




<div>

<div className="
text-[#C48B9F]
text-3xl
">

02

</div>


<h3 className="
mt-4
text-2xl
">

Confirmation

</h3>


<p className="
mt-3
text-gray-600
">

Submit your order details for verification.

</p>

</div>





<div>

<div className="
text-[#C48B9F]
text-3xl
">

03

</div>


<h3 className="
mt-4
text-2xl
">

Delivery

</h3>


<p className="
mt-3
text-gray-600
">

Receive your ebook or paperback delivery.

</p>

</div>



</div>



</div>


</section>








{/* Payment */}


<section

className="
py-32
px-6
"

>


<div

className="
max-w-xl
mx-auto
"

>


<h2

className="
text-4xl
text-center
"

>

Payment Details

</h2>


<div

className="
mt-10
bg-[#FCF8F5]
rounded-3xl
p-10
"

>

<p>

Bank Name:
<br/>
{siteData.payment.bank}

</p>


<br/>


<p>

Account:
<br/>
{siteData.payment.account}

</p>


<br/>


<p>

IBAN:
<br/>
{siteData.payment.iban}

</p>


</div>


</div>


</section>








<section

className="
pb-40
px-6
"

>


<div

className="
max-w-xl
mx-auto
"

>


<PaymentForm />


</div>


</section>



<Footer />


</main>


);

}